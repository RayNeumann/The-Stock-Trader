# The-Stock-Trader

npm install vue-router --save
npm install vue-resource --save
npm install vuex --save

npm install

npm run dev

export default [
    { id: 1, name: 'BMW', price: 110 },
    { id: 2, name: 'Google', price: 220 },
    { id: 3, name: 'Apple', price: 120 },
    { id: 4, name: 'Twitter', price: 8 }
]